
package pryboton;

import PantallaBoton.Pantalla;

public class PryBoton {

    public static void main(String[] args) {
        Pantalla pa = new Pantalla();
        pa.setVisible(true);
        pa.setLocationRelativeTo(null);
    }
    
}
