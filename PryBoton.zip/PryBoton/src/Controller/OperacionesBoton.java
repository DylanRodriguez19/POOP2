
package Controller;
public class OperacionesBoton {
   double a,b;
   public double sumar(double a, double b){
       return a+b;
   }
  public double restar(double a,double b){
      return a-b;
  }
  public double multiplicar(double a, double b ){
      return a*b;
  }
  public double dividir(double a, double b){
      if(b==0){
          return 0;
      }else{
          return a/b;
      }        
  }
  public double potencia(double base, double exponente) {
        return Math.pow(base, exponente);
    }

    public Double raizCuadrada(double a) {
        if (a < 0) {
            return null;
        }
        return Math.sqrt(a);
    }
}
